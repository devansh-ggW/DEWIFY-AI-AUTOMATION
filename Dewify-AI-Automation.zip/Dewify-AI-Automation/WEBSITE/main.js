import * as THREE from 'three';
import './styles.css';

const root = document.documentElement;
const body = document.body;
const canvas = document.querySelector('#scene-canvas');
const video = document.querySelector('#field-video');
const scrollReadout = document.querySelector('#scroll-readout');
const progressFill = document.querySelector('#progress-fill');
const statusLabel = document.querySelector('#status-label');
const statusCount = document.querySelector('#status-count');
const drawer = document.querySelector('#field-drawer');
const drawerToggle = document.querySelector('#field-toggle');
const drawerClose = document.querySelector('#field-close');
const sections = [...document.querySelectorAll('section[data-scene]')];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const sceneNames = {
  origin: ['Origin', '01'],
  threshold: ['Threshold', '02'],
  manifest: ['The field', '03'],
  signal: ['Signal', '04'],
  proof: ['Proof', '05'],
  contact: ['Open channel', '06'],
};

let sceneState = { progress: 0, pointerX: 0, pointerY: 0, active: 'origin' };
let sceneApi = null;

function clamp(value, min = 0, max = 1) { return Math.min(max, Math.max(min, value)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function mapRange(value, inMin, inMax, outMin, outMax) { return outMin + ((value - inMin) / (inMax - inMin)) * (outMax - outMin); }

function updateScrollProgress() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  sceneState.progress = max > 0 ? clamp(window.scrollY / max) : 0;
  progressFill.style.transform = `scaleX(${sceneState.progress})`;
  scrollReadout.textContent = (sceneState.progress * 100).toFixed(1).padStart(4, '0');

  // Pinned chapters can occupy several viewport heights, so use the reading line
  // rather than an intersection ratio to keep the status rail in sync with the edit.
  const readingLine = window.scrollY + window.innerHeight * 0.42;
  let current = sections[0];
  sections.forEach((section) => {
    if (section.offsetTop <= readingLine) current = section;
  });
  if (current) setActiveScene(current.dataset.scene);
}

function setActiveScene(name) {
  if (!sceneNames[name] || sceneState.active === name) return;
  sceneState.active = name;
  const [label, count] = sceneNames[name];
  statusLabel.textContent = label;
  statusCount.textContent = count;
}

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add('is-visible');
  });
}, { threshold: 0.16, rootMargin: '0px 0px -8% 0px' });
document.querySelectorAll('.reveal-up, .reveal-row').forEach((node) => revealObserver.observe(node));
sections.forEach((section) => revealObserver.observe(section));

const sceneObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) setActiveScene(entry.target.dataset.scene);
  });
}, { threshold: 0.42 });
sections.forEach((section) => sceneObserver.observe(section));

window.addEventListener('scroll', updateScrollProgress, { passive: true });
window.addEventListener('resize', updateScrollProgress);
window.addEventListener('pointermove', (event) => {
  sceneState.pointerX = (event.clientX / window.innerWidth - 0.5) * 2;
  sceneState.pointerY = (event.clientY / window.innerHeight - 0.5) * 2;
}, { passive: true });

function setDrawer(open) {
  drawer.classList.toggle('is-open', open);
  drawer.setAttribute('aria-hidden', String(!open));
  drawerToggle.setAttribute('aria-expanded', String(open));
  body.classList.toggle('is-drawer-open', open);
}
drawerToggle.addEventListener('click', () => setDrawer(true));
drawerClose.addEventListener('click', () => setDrawer(false));
drawer.addEventListener('click', (event) => { if (event.target === drawer) setDrawer(false); });
window.addEventListener('keydown', (event) => { if (event.key === 'Escape') setDrawer(false); });

document.querySelectorAll('a[href^="#"]').forEach((link) => {
  link.addEventListener('click', () => setDrawer(false));
});

function createScene() {
  try {
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, reducedMotion ? 1 : 1.65));
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x080a09, 0.045);
    const camera = new THREE.PerspectiveCamera(38, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.set(0, 0, 8.4);

    const world = new THREE.Group();
    const core = new THREE.Group();
    const rings = new THREE.Group();
    const particles = new THREE.Group();
    scene.add(world);
    world.add(core, rings, particles);

    const palette = {
      bone: new THREE.Color('#f0eee7'),
      lime: new THREE.Color('#d8ff63'),
      blue: new THREE.Color('#7382ff'),
      orange: new THREE.Color('#f26b42'),
    };

    const ambient = new THREE.AmbientLight(0x506060, 0.7);
    const key = new THREE.DirectionalLight(0xf0eee7, 3.5);
    key.position.set(4, 5, 6);
    const limeLight = new THREE.PointLight(0xd8ff63, 14, 12, 2);
    limeLight.position.set(-3, 1.5, 2);
    const blueLight = new THREE.PointLight(0x7382ff, 16, 14, 2);
    blueLight.position.set(3, -2, 1);
    scene.add(ambient, key, limeLight, blueLight);

    const sphere = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.18, 4),
      new THREE.MeshPhysicalMaterial({ color: 0xf0eee7, roughness: 0.2, metalness: 0.58, clearcoat: 0.7, clearcoatRoughness: 0.18 })
    );
    core.add(sphere);

    const wire = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.23, 3),
      new THREE.MeshBasicMaterial({ color: 0xd8ff63, wireframe: true, transparent: true, opacity: 0.33 })
    );
    core.add(wire);

    const inner = new THREE.Mesh(
      new THREE.SphereGeometry(0.72, 32, 32),
      new THREE.MeshBasicMaterial({ color: 0x7382ff, transparent: true, opacity: 0.11, blending: THREE.AdditiveBlending })
    );
    core.add(inner);

    const ringSpecs = [
      [1.72, 0.012, 0.2, 0xd8ff63],
      [2.03, 0.008, -0.45, 0xf0eee7],
      [2.35, 0.006, 0.68, 0x7382ff],
    ];
    ringSpecs.forEach(([radius, tube, tilt, color], index) => {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, tube, 8, 160), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.64 - index * 0.12 }));
      ring.rotation.x = Math.PI / 2 + tilt;
      ring.rotation.y = tilt * 0.65;
      rings.add(ring);
    });

    const crossRing = new THREE.Mesh(new THREE.TorusGeometry(1.48, 0.028, 8, 96), new THREE.MeshBasicMaterial({ color: 0xf0eee7, transparent: true, opacity: 0.28 }));
    crossRing.rotation.x = 0.75;
    crossRing.rotation.z = -0.4;
    rings.add(crossRing);

    const particleCount = reducedMotion ? 260 : 850;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const colorChoices = [palette.bone, palette.lime, palette.blue];
    for (let i = 0; i < particleCount; i += 1) {
      const radius = 2.9 + Math.random() * 4.8;
      const theta = Math.random() * Math.PI * 2;
      const y = (Math.random() - 0.5) * 5.6;
      positions[i * 3] = Math.cos(theta) * radius;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = Math.sin(theta) * radius - 1;
      const color = colorChoices[Math.floor(Math.random() * colorChoices.length)];
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    const particleMaterial = new THREE.PointsMaterial({ size: 0.025, sizeAttenuation: true, vertexColors: true, transparent: true, opacity: 0.62, blending: THREE.AdditiveBlending, depthWrite: false });
    particles.add(new THREE.Points(particleGeometry, particleMaterial));

    const signalBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 10, 6), new THREE.MeshBasicMaterial({ color: 0xd8ff63, transparent: true, opacity: 0.28 }));
    signalBeam.rotation.z = Math.PI / 2;
    signalBeam.position.x = -3.5;
    world.add(signalBeam);

    let targetX = 0;
    let targetY = 0;
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight, false);
    };
    window.addEventListener('resize', onResize);

    const clock = new THREE.Clock();
    const animate = () => {
      const time = clock.getElapsedTime();
      const p = sceneState.progress;
      targetX = sceneState.pointerX * 0.26;
      targetY = sceneState.pointerY * 0.18;
      const easedP = p * p * (3 - 2 * p);

      core.rotation.y += 0.0025;
      core.rotation.x = lerp(core.rotation.x, targetY + easedP * 0.58, 0.045);
      core.rotation.z = lerp(core.rotation.z, targetX * 0.35 + easedP * -0.35, 0.045);
      wire.rotation.y -= 0.004;
      inner.scale.setScalar(1 + Math.sin(time * 1.4) * 0.035 + easedP * 0.12);
      rings.rotation.y += 0.0013;
      rings.rotation.x = lerp(rings.rotation.x, targetY * 0.5 + easedP * 0.32, 0.03);
      particles.rotation.y = time * 0.015 + easedP * 1.25;
      particles.rotation.x = easedP * -0.2;
      world.position.x = lerp(world.position.x, targetX * 0.32 + Math.sin(easedP * Math.PI) * 0.2, 0.04);
      world.position.y = lerp(world.position.y, targetY * -0.24 + Math.sin(time * 0.55) * 0.05, 0.04);
      world.scale.setScalar(lerp(world.scale.x, 1 + easedP * 0.16, 0.04));
      camera.position.x = lerp(camera.position.x, targetX * 0.5 + Math.sin(easedP * Math.PI * 1.3) * 0.6, 0.035);
      camera.position.y = lerp(camera.position.y, targetY * -0.35 + Math.cos(easedP * Math.PI) * 0.24, 0.035);
      camera.position.z = lerp(camera.position.z, 8.4 - easedP * 1.35 + Math.sin(easedP * Math.PI) * 0.35, 0.035);
      camera.lookAt(0, 0, 0);
      limeLight.intensity = 12 + Math.sin(time * 1.2) * 2 + easedP * 4;
      blueLight.intensity = 12 + Math.cos(time * 0.8) * 2 + (1 - easedP) * 5;
      renderer.render(scene, camera);
    };
    renderer.setAnimationLoop(animate);

    return { renderer, onResize };
  } catch (error) {
    console.warn('WebGL scene unavailable; using fallback field.', error);
    body.classList.add('webgl-fallback');
    return null;
  }
}

sceneApi = createScene();
if (!sceneApi) body.classList.add('webgl-fallback');

if (video) {
  const playVideo = () => video.play().catch(() => {});
  if (!reducedMotion) {
    playVideo();
    document.addEventListener('visibilitychange', () => { if (!document.hidden) playVideo(); });
  }
  video.addEventListener('error', () => video.closest('.film-frame')?.classList.add('media-fallback'));
}

window.addEventListener('load', () => {
  updateScrollProgress();
  body.classList.add('is-ready');
}, { once: true });

updateScrollProgress();
