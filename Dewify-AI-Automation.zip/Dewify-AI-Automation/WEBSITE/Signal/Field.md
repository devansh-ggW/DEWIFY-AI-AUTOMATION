# Signal / Field

Signal / Field is a single-scroll cinematic studio experience built around a genuine Three.js scene, a locally encoded abstract film loop, and scroll-linked editorial storytelling.

## Run locally

```bash
pnpm install
pnpm dev
```

The app listens on port 3000. Production output is created with `pnpm build`.

## Art direction

The direction is **industrial editorial / nocturnal instrument**: a near-black field, bone typography, a single acid-lime signal color, and small blue calibration marks. The page behaves like a designed instrument rather than a marketing template.

- **Core principles:** choreographed pacing, high-contrast typography, restrained atmosphere, and motion that communicates system state.
- **Layout paradigm:** a long vertical score with a fixed 3D instrument, pinned narrative passages, and offset content bands.
- **Signature elements:** the wireframe signal core, hairline calibration marks, and a small field-status rail that updates as the story changes.
- **Interaction philosophy:** scroll is the edit; pointer movement is a gentle camera hand; controls expose more of the field without breaking the mood.
- **Typography:** condensed display headlines paired with compact grotesk body copy, using local system fallbacks for reliable loading.
- **Brand essence:** a creative technology studio for brands that need a signal with physical presence; precise, atmospheric, and quietly radical.

## Structure

- `index.html` — semantic page structure and metadata.
- `src/main.js` — Three.js scene, scroll mapping, pointer interaction, navigation, fallback logic.
- `src/styles.css` — responsive art direction, section transitions, reduced-motion and WebGL fallback styling.
- `public/media/field-loop.mp4` — small locally encoded abstract film loop used in the central scroll chapter.
- `public/manus-routes.json` — route declaration for the managed preview.

## Validation performed

The intended validation flow is `pnpm build`, a local preview request, and managed screenshots at desktop/mobile widths. The Three.js scene caps device pixel ratio, uses lightweight primitives, and falls back to an HTML visual when WebGL is unavailable.
