# DEWIFY AI AUTOMATION

A small Windows-first, self-hosted AI customer-message bot package for:

- WhatsApp Business Platform
- Instagram direct messages
- Facebook Page Messenger

There is no website widget. The three channels share one AI connection and one `BUSINESS_INFO.txt` file. Read `1 - READ THIS FIRST.txt`, then the `MANUAL.txt` inside each channel folder.

The app uses official Meta webhooks and APIs. Real messages require valid Meta app credentials, permissions, account IDs, and a public HTTPS webhook URL. A temporary Cloudflare Quick Tunnel is included as an optional test path; it is not a production hosting solution.

## Local tests

Run `python -m unittest discover -s tests -v` from this folder. Tests validate message parsing, webhook signatures, and the health / webhook-verification routes. They do not test live Meta account access or delivery.
