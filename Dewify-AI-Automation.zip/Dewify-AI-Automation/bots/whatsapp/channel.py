"""WhatsApp Cloud API: extract inbound text and send a reply."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

from app import settings


@dataclass(frozen=True)
class InboundMessage:
    message_id: str
    sender_id: str
    text: str


def extract_messages(payload: dict) -> list[InboundMessage]:
    found: list[InboundMessage] = []
    for entry in payload.get("entry", []):
        if not isinstance(entry, dict):
            continue
        for change in entry.get("changes", []):
            if not isinstance(change, dict):
                continue
            value = change.get("value", {})
            if not isinstance(value, dict):
                continue
            for message in value.get("messages", []):
                if not isinstance(message, dict) or message.get("type") != "text":
                    continue
                sender, mid = message.get("from"), message.get("id")
                text_obj = message.get("text", {})
                text = text_obj.get("body") if isinstance(text_obj, dict) else None
                if all(isinstance(v, str) and v.strip() for v in (sender, mid, text)):
                    found.append(InboundMessage(mid, sender, text.strip()))
    return found


async def send_text(recipient: str, text: str) -> None:
    cfg = settings.CHANNELS["whatsapp"]
    if not cfg["access_token"] or not cfg["account_id"]:
        raise RuntimeError("WhatsApp settings are missing in .env.")
    url = f"{cfg['graph_base_url']}/{settings.META_GRAPH_VERSION}/{cfg['account_id']}/messages"
    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": recipient,
        "type": "text",
        "text": {"preview_url": False, "body": text[:4000]},
    }
    headers = {"Authorization": f"Bearer {cfg['access_token']}"}
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.post(url, headers=headers, json=payload)
        if response.is_error:
            raise RuntimeError(f"WhatsApp API returned HTTP {response.status_code}.")
