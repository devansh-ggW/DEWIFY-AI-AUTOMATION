"""WhatsApp Cloud API adapter."""
