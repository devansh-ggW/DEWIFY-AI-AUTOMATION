# WhatsApp AI Bot Manual

This folder documents the WhatsApp channel. The WhatsApp implementation is in `bots/whatsapp/channel.py`; configuration lives in the root `.env` file.

## What it does

- Receives inbound text messages through the official WhatsApp Business Platform Cloud API.
- Sends the text to the configured AI model with short-lived conversation context.
- Sends the AI reply back to the person who started the conversation.
- Ignores status events, media-only messages, and unsupported message types.

It does not send unsolicited campaigns, use WhatsApp Web sessions, scrape accounts, or bypass Meta's messaging policies.

## Requirements

- A Meta developer app with WhatsApp configured.
- A WhatsApp Business Account and a phone number registered for the Cloud API.
- An access token with the required permissions for that number.
- The phone number ID from Meta's WhatsApp API setup page.
- A server reachable by Meta over HTTPS for webhook testing and production.
- The AI endpoint must pass `python -m scripts.check_ai`.

## Configure the bot

Open the root `.env` and set:

```env
WHATSAPP_ACCESS_TOKEN=your_whatsapp_access_token
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id
WHATSAPP_GRAPH_BASE_URL=https://graph.facebook.com
META_GRAPH_VERSION=v26.0
META_APP_SECRET=your_meta_app_secret
META_WEBHOOK_SIGNATURE_REQUIRED=true
```

Keep the real access token and app secret in `.env` only. Do not paste them into a manual, website page, screenshot, source code, or customer-facing support chat. Do not distribute your own `.env` with the product. The setup script generates the Verify Token; copy it into Meta when configuring the webhook.

## Configure Meta webhooks

1. In Meta for Developers, open the app and add/configure WhatsApp.
2. Start with Meta's test number and recipient allowlist. Do not assume a test token is a durable production token.
3. Start the server and expose it through a public HTTPS domain or a temporary HTTPS tunnel for testing.
4. Set the WhatsApp webhook callback URL to `https://YOUR_PUBLIC_HOST/webhooks/whatsapp`.
5. Enter the exact `META_VERIFY_TOKEN` value from `.env` in Meta's Verify Token field. The setup script generates a unique value when creating `.env`; if you copied the example manually, replace its placeholder first.
6. Complete verification. The application returns Meta's challenge string only when the mode and verify token match.
7. Subscribe the WhatsApp webhook object to the `messages` field. Also ensure the WhatsApp Business Account is subscribed to the app as required by Meta's current setup flow.
8. Keep `META_WEBHOOK_SIGNATURE_REQUIRED=true` and set `META_APP_SECRET` to the app secret belonging to that same Meta app.
9. Send a real test message to the configured number and confirm that the server logs show an accepted webhook and the phone receives a reply.

Use Meta's current official guide because dashboard labels and permission requirements can change: https://developers.facebook.com/documentation/business-messaging/whatsapp/get-started

## Test before publishing

1. Confirm `/health` reports `whatsapp_configured: true` and `meta_signature_verification_configured: true`.
2. Check the model with `python -m scripts.check_ai`.
3. Confirm the webhook URL passes Meta verification.
4. Send an inbound text from an allowed test recipient.
5. Confirm a single reply arrives. Meta may retry webhooks, so this bundle de-duplicates message IDs in memory.

## Messaging rules and limitations

- The bot only replies to incoming text messages.
- WhatsApp's customer-service window and template requirements still apply. Do not use this bot to initiate messages outside Meta's allowed rules.
- Media, interactive buttons, message templates, status updates, handover routing, CRM operations, and order actions are not implemented.
- A server restart clears the in-memory conversation history and duplicate-event cache.
- For multiple numbers or high availability, extend the code and tests; the shipped configuration targets one WhatsApp phone-number ID per installation.

## If a reply does not arrive

Read `manuals/TROUBLESHOOTING.md`, then check the official send-message and webhook documentation:

- https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/send-messages
- https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview
