"""Messaging channel adapters."""
