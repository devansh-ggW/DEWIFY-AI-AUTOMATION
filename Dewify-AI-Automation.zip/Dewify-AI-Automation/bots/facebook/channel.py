"""Facebook Messenger Platform: extract inbound text and send a reply."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

from app import settings


@dataclass(frozen=True)
class InboundMessage:
    message_id: str
    sender_id: str
    text: str


def extract_messages(payload: dict) -> list[InboundMessage]:
    found: list[InboundMessage] = []
    for entry in payload.get("entry", []):
        if not isinstance(entry, dict):
            continue
        for event in entry.get("messaging", []):
            if not isinstance(event, dict):
                continue
            message = event.get("message")
            if not isinstance(message, dict) or message.get("is_echo") or message.get("is_deleted"):
                continue
            sender = event.get("sender", {})
            sender_id = sender.get("id") if isinstance(sender, dict) else None
            mid = message.get("mid") or message.get("id")
            text = message.get("text")
            if all(isinstance(v, str) and v.strip() for v in (sender_id, mid, text)):
                found.append(InboundMessage(mid, sender_id, text.strip()))
    return found


async def send_text(recipient: str, text: str) -> None:
    cfg = settings.CHANNELS["facebook"]
    if not cfg["access_token"]:
        raise RuntimeError("Facebook settings are missing in .env.")
    url = f"{cfg['graph_base_url']}/{settings.META_GRAPH_VERSION}/me/messages"
    payload = {
        "recipient": {"id": recipient},
        "messaging_type": "RESPONSE",
        "message": {"text": text[:2000]},
    }
    headers = {"Authorization": f"Bearer {cfg['access_token']}"}
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.post(url, headers=headers, json=payload)
        if response.is_error:
            raise RuntimeError(f"Facebook Messenger API returned HTTP {response.status_code}.")
