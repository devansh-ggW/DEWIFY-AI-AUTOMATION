"""Facebook Messenger adapter."""
