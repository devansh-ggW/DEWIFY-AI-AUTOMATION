"""Instagram Messaging API with Instagram Login: incoming text and replies."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

from app import settings


@dataclass(frozen=True)
class InboundMessage:
    message_id: str
    sender_id: str
    text: str


def extract_messages(payload: dict) -> list[InboundMessage]:
    found: list[InboundMessage] = []
    for entry in payload.get("entry", []):
        if not isinstance(entry, dict):
            continue
        for event in entry.get("messaging", []):
            if not isinstance(event, dict):
                continue
            message = event.get("message")
            if not isinstance(message, dict) or message.get("is_echo") or message.get("is_deleted"):
                continue
            sender = event.get("sender", {})
            sender_id = sender.get("id") if isinstance(sender, dict) else None
            mid = message.get("mid") or message.get("id")
            text = message.get("text")
            if all(isinstance(v, str) and v.strip() for v in (sender_id, mid, text)):
                found.append(InboundMessage(mid, sender_id, text.strip()))
    return found


async def send_text(recipient: str, text: str) -> None:
    cfg = settings.CHANNELS["instagram"]
    if not cfg["access_token"] or not cfg["account_id"]:
        raise RuntimeError("Instagram settings are missing in .env.")
    url = f"{cfg['graph_base_url']}/{settings.META_GRAPH_VERSION}/{cfg['account_id']}/messages"
    payload = {"recipient": {"id": recipient}, "message": {"text": text[:990]}}
    headers = {"Authorization": f"Bearer {cfg['access_token']}"}
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.post(url, headers=headers, json=payload)
        if response.is_error:
            raise RuntimeError(f"Instagram API returned HTTP {response.status_code}.")
