# Instagram AI Bot Manual

This folder documents Instagram DM automation. The Instagram implementation is in `bots/instagram/channel.py`; credentials and API configuration live in the root `.env` file.

## What it does

- Receives supported inbound text messages from an Instagram professional account through Meta webhooks.
- Sends the text to the shared AI model and retains short-lived conversation context in memory.
- Replies to the sender using the Instagram Messaging API.
- Ignores message echoes and events that do not contain supported text.

It does not automate Instagram Web, store browser cookies, scrape DMs, send bulk unsolicited messages, or bypass Meta's messaging rules.

## Requirements

- An Instagram Business or Creator account.
- A Meta developer app configured for the Instagram API with Instagram Login.
- An Instagram access token with the required messaging permission.
- The Instagram account ID used by the selected API login flow.
- A public HTTPS server URL for webhooks.
- A working model endpoint, verified with `python -m scripts.check_ai`.

## Configure the bot

Set these values in the root `.env`:

```env
INSTAGRAM_ACCESS_TOKEN=your_instagram_access_token
INSTAGRAM_ACCOUNT_ID=your_instagram_account_id
INSTAGRAM_GRAPH_BASE_URL=https://graph.instagram.com
META_GRAPH_VERSION=v26.0
META_APP_SECRET=your_meta_app_secret
META_WEBHOOK_SIGNATURE_REQUIRED=true
```

Use a token issued for the same Instagram account and login method. Never put tokens into JavaScript or any website file. Some tokens expire or require refresh; monitor the account connection and renew according to Meta's current token rules.
The setup script generates `META_VERIFY_TOKEN` in the root `.env`. Keep that generated value and enter the exact same string in Meta webhook settings; do not replace it with an example value.

## Configure Instagram Messaging API

1. Convert the account to a Professional account if it is not already Business or Creator.
2. In Meta for Developers, configure the Instagram API with Instagram Login flow and request the current messaging permission, typically `instagram_business_manage_messages`.
3. Set the webhook callback URL to `https://YOUR_PUBLIC_HOST/webhooks/instagram` and the same `META_VERIFY_TOKEN` stored in `.env`.
4. Subscribe the app to the `messages` webhook field.
5. Ensure the specific Instagram professional account is subscribed to the app's `messages` webhook field. Follow Meta's current account subscription instructions; configuring the app-level callback alone may not subscribe the account.
6. Set the Meta App Secret in `.env` so the raw webhook body is checked with `X-Hub-Signature-256`.
7. Send a DM from a test account to the professional account and verify one reply arrives.

Official references:

- Instagram Login Messaging API: https://developers.facebook.com/documentation/instagram-platform/instagram-api-with-instagram-login/messaging-api
- Instagram webhooks: https://developers.facebook.com/documentation/instagram-platform/webhooks
- Instagram Platform overview: https://developers.facebook.com/documentation/instagram-platform/overview

## Messaging rules and limitations

- The automated reply is triggered by an inbound text. The account must be eligible to use the official messaging API and the user must be in a platform-permitted messaging window.
- This is not a cold-DM sender. Do not use it to message people who have not contacted the account or to send spam.
- Media, attachments, postbacks, story-specific handlers, human-agent routing, and advanced messaging features are not implemented.
- Instagram message text is capped conservatively before sending. Long answers are shortened; keep the AI's response brief.
- One Instagram account is configured per installation.
- Short conversation history and message IDs are stored in memory and disappear on process restart.

## Test before publishing

1. Check `/health` reports `instagram_configured: true` and signature verification configured.
2. Check the model using `python -m scripts.check_ai`.
3. Confirm Meta webhook verification succeeds.
4. Send a simple text DM from a second test account, then verify a reply arrives.
5. Test an echo/status event and confirm the bot does not reply to its own outgoing message.

If a test fails, read `manuals/TROUBLESHOOTING.md` and compare your configuration to Meta's current official documentation.
