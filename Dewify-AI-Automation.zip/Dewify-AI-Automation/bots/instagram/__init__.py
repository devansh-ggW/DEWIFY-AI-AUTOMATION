"""Instagram Messaging API adapter."""
