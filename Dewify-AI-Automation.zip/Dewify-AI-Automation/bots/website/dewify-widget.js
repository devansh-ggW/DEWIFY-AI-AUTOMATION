/* Dewify AI Automation website chat widget. API credentials stay on the server. */
(() => {
  "use strict";

  const script = document.currentScript;
  if (!script) {
    console.error("Dewify widget: place the script in a normal script tag.");
    return;
  }

  const apiBase = (script.dataset.apiUrl || "").trim().replace(/\/+$/, "");
  const title = script.dataset.title || "Ask us";
  const placeholder = script.dataset.placeholder || "Write a message";

  if (!apiBase || !/^https?:\/\//i.test(apiBase)) {
    console.error("Dewify widget: set data-api-url to the public API base URL.");
    return;
  }

  const root = document.createElement("div");
  root.setAttribute("data-dewify-widget", "true");
  document.body.appendChild(root);
  const shadow = root.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    * { box-sizing: border-box; }
    .launcher { position: fixed; right: 22px; bottom: 22px; z-index: 2147483000; border: 0; border-radius: 999px; padding: 14px 18px; background: #17171b; color: #f5f5f2; font: 600 14px/1.2 system-ui, sans-serif; box-shadow: 0 8px 28px #0003; cursor: pointer; }
    .panel { position: fixed; right: 22px; bottom: 82px; z-index: 2147483000; display: none; flex-direction: column; width: min(360px, calc(100vw - 28px)); height: min(500px, calc(100vh - 120px)); overflow: hidden; background: #fff; color: #17171b; border: 1px solid #e4e4e7; border-radius: 18px; box-shadow: 0 18px 60px #0003; font: 14px/1.45 system-ui, sans-serif; }
    .panel[data-open="true"] { display: flex; }
    .header { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 15px 16px; border-bottom: 1px solid #e4e4e7; background: #fafafa; }
    .heading { margin: 0; font: 650 15px/1.2 system-ui, sans-serif; }
    .close { border: 0; background: transparent; color: #52525b; font: 22px/1 system-ui, sans-serif; cursor: pointer; padding: 2px 5px; }
    .messages { display: flex; flex: 1; flex-direction: column; gap: 9px; overflow-y: auto; padding: 14px; background: #fff; }
    .message { max-width: 88%; padding: 10px 12px; border-radius: 13px; white-space: pre-wrap; overflow-wrap: anywhere; font: 14px/1.45 system-ui, sans-serif; }
    .assistant { align-self: flex-start; background: #f1f1f4; color: #18181b; border-bottom-left-radius: 4px; }
    .user { align-self: flex-end; background: #24242b; color: #fff; border-bottom-right-radius: 4px; }
    .status { min-height: 18px; padding: 0 14px 7px; color: #71717a; font: 12px/1.3 system-ui, sans-serif; }
    .form { display: flex; gap: 8px; padding: 10px; border-top: 1px solid #e4e4e7; background: #fff; }
    .input { min-width: 0; flex: 1; border: 1px solid #d4d4d8; border-radius: 11px; padding: 10px 11px; outline: none; background: #fff; color: #18181b; font: 14px/1.3 system-ui, sans-serif; }
    .input:focus { border-color: #71717a; box-shadow: 0 0 0 2px #71717a22; }
    .send { border: 0; border-radius: 11px; padding: 0 14px; background: #24242b; color: #fff; font: 600 13px/1 system-ui, sans-serif; cursor: pointer; }
    .send:disabled, .input:disabled { opacity: .55; cursor: wait; }
    @media (max-width: 480px) { .panel { right: 10px; bottom: 76px; width: calc(100vw - 20px); height: min(520px, calc(100vh - 100px)); } .launcher { right: 12px; bottom: 12px; } }
  `;

  const launcher = document.createElement("button");
  launcher.className = "launcher";
  launcher.type = "button";
  launcher.textContent = title;
  launcher.setAttribute("aria-expanded", "false");
  launcher.setAttribute("aria-label", `${title} chat`);

  const panel = document.createElement("section");
  panel.className = "panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", title);
  panel.setAttribute("aria-modal", "false");
  panel.dataset.open = "false";

  const header = document.createElement("div");
  header.className = "header";
  const heading = document.createElement("h2");
  heading.className = "heading";
  heading.textContent = title;
  const close = document.createElement("button");
  close.className = "close";
  close.type = "button";
  close.textContent = "Close";
  close.setAttribute("aria-label", "Close chat");
  header.append(heading, close);

  const messages = document.createElement("div");
  messages.className = "messages";
  messages.setAttribute("role", "log");
  messages.setAttribute("aria-live", "polite");

  const status = document.createElement("div");
  status.className = "status";
  status.setAttribute("aria-live", "polite");

  const form = document.createElement("form");
  form.className = "form";
  const input = document.createElement("input");
  input.className = "input";
  input.type = "text";
  input.name = "message";
  input.maxLength = 4000;
  input.placeholder = placeholder;
  input.autocomplete = "off";
  input.setAttribute("aria-label", placeholder);
  const send = document.createElement("button");
  send.className = "send";
  send.type = "submit";
  send.textContent = "Send";
  form.append(input, send);
  panel.append(header, messages, status, form);
  shadow.append(style, launcher, panel);

  const sessionId = (() => {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}_${Math.random().toString(36).slice(2)}`;
  })();

  function appendMessage(kind, text) {
    const bubble = document.createElement("div");
    bubble.className = `message ${kind}`;
    // Customer and model text is always inserted as text, never interpreted as HTML.
    bubble.textContent = text;
    messages.appendChild(bubble);
    messages.scrollTop = messages.scrollHeight;
  }

  function setOpen(open) {
    panel.dataset.open = String(open);
    launcher.setAttribute("aria-expanded", String(open));
    if (open) input.focus();
  }

  launcher.addEventListener("click", () => setOpen(panel.dataset.open !== "true"));
  close.addEventListener("click", () => setOpen(false));

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = input.value.trim();
    if (!message || send.disabled) return;

    appendMessage("user", message);
    input.value = "";
    input.disabled = true;
    send.disabled = true;
    status.textContent = "Thinking...";

    try {
      const response = await fetch(`${apiBase}/api/website/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, message }),
        mode: "cors",
        credentials: "omit"
      });
      let data = {};
      try { data = await response.json(); } catch (_) { data = {}; }
      if (!response.ok) {
        const detail = typeof data.detail === "string" ? data.detail : "The assistant could not respond. Check the setup and try again.";
        throw new Error(detail);
      }
      if (typeof data.reply !== "string" || !data.reply.trim()) {
        throw new Error("The assistant returned an empty reply.");
      }
      appendMessage("assistant", data.reply);
      status.textContent = "";
    } catch (error) {
      status.textContent = error instanceof Error ? error.message : "Connection failed. Check your internet connection and try again.";
    } finally {
      input.disabled = false;
      send.disabled = false;
      input.focus();
    }
  });

  appendMessage("assistant", "Hello. How can I help you?");
})();
