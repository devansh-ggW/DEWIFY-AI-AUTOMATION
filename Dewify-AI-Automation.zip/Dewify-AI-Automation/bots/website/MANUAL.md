# Website AI Bot Manual

This folder contains the embeddable widget (`dewify-widget.js`) and a local preview page (`demo.html`). The backend is the root application running at `/api/website/chat`.

## What it does

- Adds a small chat launcher to an existing website.
- Sends a text message to the Dewify backend.
- Shows the model's text reply in the site's widget.
- Keeps session history in the backend's short-lived memory store.

The widget uses safe text insertion for all model output. It does not place an AI API key or Meta access token in browser JavaScript.

## Requirements

- The Dewify backend running on a stable public HTTPS URL for production.
- A working AI endpoint, verified by `python -m scripts.check_ai`.
- The website domain added exactly to `WEBSITE_ALLOWED_ORIGINS` in the root `.env`.
- The `dewify-widget.js` file copied into your site's public assets folder, or loaded from the backend's `/static/dewify-widget.js` route.

## Local test

1. Run `setup.bat` and edit the model settings in `.env`.
2. Run `start.bat`.
3. In a second terminal from the project folder, run:

   ```bat
   .venv\Scripts\python.exe -m http.server 5500 --directory bots\website
   ```

4. Open `http://localhost:5500/demo.html`.
5. Send a short chat message. The backend must be able to reach the selected model endpoint.

The default `.env.example` includes local test origins on port 5500. If you change the demo port or hostname, add the exact origin to `WEBSITE_ALLOWED_ORIGINS` and restart the backend.

## Add it to a real website

Copy `dewify-widget.js` to the website's public assets folder, for example `/assets/dewify-widget.js`. Add this snippet before the closing `</body>` tag and replace the API URL with your deployed Dewify backend:

```html
<script
  src="/assets/dewify-widget.js"
  data-api-url="https://bot.your-domain.com"
  data-title="Ask our team"
  data-placeholder="Write a message"
  defer>
</script>
```

The backend URL must be public and use HTTPS when the website uses HTTPS. Add the exact website origin, with no path and no trailing slash, to the root `.env`:

```env
WEBSITE_ALLOWED_ORIGINS=https://your-domain.com,https://www.your-domain.com
```

Include each hostname that should be allowed. Restart the backend after editing `.env`.

If you prefer not to host the JavaScript file on your own website, load it from your backend instead:

```html
<script
  src="https://bot.your-domain.com/static/dewify-widget.js"
  data-api-url="https://bot.your-domain.com"
  data-title="Ask our team"
  defer>
</script>
```

## Deployment notes

- The browser calls the backend, not the model provider directly. Keep AI keys on the server.
- CORS is not a replacement for authentication or rate limits. This widget enforces an exact Origin allowlist and a per-IP in-memory limit, but a public commercial deployment should add stronger abuse controls, monitoring, and persistent shared rate limiting.
- The built-in rate limiter is process-local. Use one worker with the supplied setup unless you replace the in-memory stores for multi-worker deployment.
- Never embed the server's `.env` or any API keys into the website folder.
- The widget currently supports text chat only. It does not collect email addresses, book appointments, access customer databases, or perform transactions.
