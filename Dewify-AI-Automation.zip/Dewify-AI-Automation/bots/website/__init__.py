"""Website chat widget and setup manual."""
