@echo off
setlocal
cd /d "%~dp0"
title Dewify AI Automation - Running

if not exist ".venv\Scripts\python.exe" (
    echo Python environment not found. Starting setup first...
    call "SETUP.bat"
    if errorlevel 1 exit /b 1
)

if not exist ".env" (
    echo ERROR: .env is missing. Run SETUP.bat first.
    pause
    exit /b 1
)

echo ============================================================
echo DEWIFY AI AUTOMATION IS STARTING
echo ============================================================
echo Keep this window open while the bots are running.
echo Local health check: http://127.0.0.1:8000/health
echo Stop the service with CTRL+C.
echo.
".venv\Scripts\python.exe" -m app.server
pause
