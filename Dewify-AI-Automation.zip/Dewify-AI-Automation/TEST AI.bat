@echo off
setlocal
cd /d "%~dp0"
title Dewify AI Automation - Test AI

if not exist ".venv\Scripts\python.exe" (
    echo Run SETUP.bat first.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" -m app.check_ai
echo.
pause
