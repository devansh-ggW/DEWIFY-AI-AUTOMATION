# Privacy and Security Notes

This file helps the operator deploy Dewify AI Automation responsibly. It is not legal advice; each business must determine its own notice, consent, and retention obligations.

## Credentials

- Store AI API keys, Meta access tokens, the Meta App Secret, and the webhook Verify Token in the root `.env` file or a managed secret store.
- Do not commit `.env`, copy it into website assets, send it to customers, or include it in screenshots or logs.
- Rotate a token immediately if it is exposed. Revoke credentials that are no longer needed.
- The product's browser widget only contains public configuration and calls the backend. It must never contain server-side model or Meta credentials.

## Message handling

- Incoming text is processed in memory and sent to the AI endpoint configured by `AI_BASE_URL`.
- When `AI_BASE_URL` points at Ollama or LM Studio on the same machine, inference can stay local. When it points to a hosted API or another machine, message text is sent to that provider; review that provider's terms and data handling before using customer messages.
- The application does not write message bodies or access tokens to its own logs by design. It keeps recent conversation turns and webhook event IDs in process memory, and those entries are cleared on process restart or by the configured cleanup logic.
- There is no database, message export, audit history, automatic deletion workflow, or multi-tenant account system in this bundle.
- The business using the bot is responsible for an appropriate privacy notice, legal basis or consent where required, human escalation, retention decisions, and handling requests from people whose messages are processed.

## Public deployment

- Serve webhooks and the website API through HTTPS.
- Keep `META_WEBHOOK_SIGNATURE_REQUIRED=true` and configure the correct `META_APP_SECRET`.
- Restrict `WEBSITE_ALLOWED_ORIGINS` to the exact domains that need the widget.
- Do not expose Ollama or LM Studio's local model server directly to the public internet.
- Use a maintained host, access controls, firewall rules, monitoring, and regular dependency updates.
- The built-in rate limiter is process-local and intended as a basic guard. It is not sufficient protection against a determined attacker or a high-traffic abuse campaign.
- Do not scale to multiple application workers without replacing the in-memory conversation, rate-limit, and deduplication stores with shared implementations.

## Platform compliance

Only connect accounts the operator is authorized to manage. Follow Meta's current WhatsApp and Instagram messaging, privacy, opt-in, user-initiated conversation, and message-window requirements. This package does not implement outbound marketing campaigns and should not be used to spam users.
