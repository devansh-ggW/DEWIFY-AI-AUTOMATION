# AI Model Configuration Manual

All three channels use the same OpenAI-compatible Chat Completions interface. To switch between compatible models, edit three values in the root `.env` and restart the server:

```env
AI_BASE_URL=http://127.0.0.1:11434/v1
AI_API_KEY=ollama
AI_MODEL=qwen3:8b
```

The model name must be valid for the endpoint you select. The application does not enumerate or download every model automatically. A runtime must already have the model installed or the cloud provider must expose it to the API key.

## Supported configurations

| Runtime | Example base URL | API key value | Model value |
|---|---|---|---|
| Ollama local | `http://127.0.0.1:11434/v1` | `ollama` | Exact tag from `ollama list` |
| LM Studio local server | `http://127.0.0.1:1234/v1` | Local placeholder accepted by that server | Exact model ID shown by LM Studio |
| OpenAI API | `https://api.openai.com/v1` | Your API key | Enabled API model ID |
| Another compatible provider | Provider's documented base URL | Provider's key | Provider's model ID |

The provider must support `POST /chat/completions` and return the standard `choices[0].message.content` field. APIs that use a different protocol need an adapter; changing the name alone cannot make an unrelated runtime compatible.

## Ollama setup

1. Install and start Ollama on the same machine as the Dewify server, or configure a network-accessible Ollama host.
2. Run `ollama list` to view installed models.
3. If required, pull a model, for example `ollama pull qwen3:8b`.
4. Copy its exact name into `AI_MODEL`.
5. Restart the server and run `python -m scripts.check_ai`.

Use an installed model name directly. The optional `ollama/Modelfile` is only for creating a customized Ollama model. If you use it, edit its `FROM` line to a model that Ollama already has and run:

```sh
ollama create dewify-assistant -f ollama/Modelfile
```

Then set `AI_MODEL=dewify-assistant` in `.env` and restart. If you later change the model inside that Modelfile, run the `ollama create` command again. The application itself does not edit or download model weights.

## LM Studio setup

1. Install the model through LM Studio and load it.
2. Start LM Studio's local server.
3. Copy the shown API base URL and model ID into `.env`.
4. Run the AI connection check.

If another device must reach the runtime, configure network access deliberately. Do not expose an unauthenticated model endpoint to the public internet.

## Hosted provider setup

Use the provider's exact API base URL and model identifier. Put the API key in `.env` on the machine hosting the backend. Never put the provider key in `dewify-widget.js`, a website snippet, a downloadable front-end file, or a public repository.

## Important limits

- Not every model is suitable for every task. Some lack instruction-following ability, need different context sizes, or are too large for the customer's hardware.
- Model names are not globally universal. `qwen3:8b` is an Ollama tag, not necessarily the model identifier a hosted provider expects.
- If a model is installed but its runtime has no compatible API endpoint, changing `AI_MODEL` alone will not connect to it.
- The model runs on the server configured in `AI_BASE_URL`. A customer's local Ollama model is not reachable by a cloud-hosted backend unless the backend can securely reach that machine.
