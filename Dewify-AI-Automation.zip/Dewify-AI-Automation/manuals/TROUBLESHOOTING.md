# Troubleshooting

## The server does not start

- Use Python 3.10 or newer.
- Run `setup.bat` on Windows or `./setup.sh` on macOS/Linux.
- Confirm commands are run from the extracted project folder.
- Do not rename or remove the `app` package or `config` directory.
- Read the traceback and address the first concrete error from this project rather than reinstalling everything blindly.

## `python -m scripts.check_ai` fails

- Confirm the model runtime is running.
- Check `AI_BASE_URL`; Ollama commonly exposes `http://127.0.0.1:11434/v1` and LM Studio's local server commonly uses port 1234.
- Check the exact model ID with `ollama list` or the runtime interface.
- For hosted APIs, confirm the API key is valid, access is enabled, and the model name is allowed for that key.
- If the request times out, try a smaller model, lower `AI_MAX_TOKENS`, or increase `AI_TIMEOUT_SECONDS`.

## Meta says the webhook URL cannot be verified

- The callback needs a publicly reachable HTTPS URL; `127.0.0.1` is not reachable from Meta.
- The path must be exactly `/webhooks/whatsapp` or `/webhooks/instagram`.
- The Meta Verify Token must exactly equal `META_VERIFY_TOKEN` in `.env`.
- The HTTP GET verification handler does not require an App Secret signature; POST events do.
- Confirm the tunnel or reverse proxy forwards requests to the correct local port.

## POST webhook returns 503 or 401

- `503`: `META_WEBHOOK_SIGNATURE_REQUIRED=true` but `META_APP_SECRET` is blank. Set the app secret from the same Meta app and restart.
- `401`: the `X-Hub-Signature-256` signature did not match. Check for an incorrect app secret, wrong Meta app, proxy body mutation, or a payload altered before verification.
- Do not disable signature verification in production. Setting it to `false` is for controlled local testing only.

## Meta webhook returns 200 but there is no reply

- Check the server terminal for an error after webhook acceptance.
- Check `/health` for the relevant channel's configuration flags.
- Verify the access token, account or phone number ID, app permissions, account subscriptions, and API version.
- Test with inbound text first. The current implementation intentionally ignores media, attachments, postbacks, and status updates.
- Respect each platform's user-initiated conversation and messaging-window rules.

## Website widget says the origin is not allowed

- Add the exact site origin to `WEBSITE_ALLOWED_ORIGINS`, such as `https://example.com` or `https://www.example.com`.
- Include both hostnames if the site uses both. Do not include page paths; do not add trailing slashes.
- Restart the backend after editing `.env`.
- Make sure the website can reach the `data-api-url` host and that both are served over HTTPS in production.

## Website widget shows a network or CORS error

- Open the browser developer console and Network tab.
- Confirm the API server is online and `/health` responds.
- Confirm the widget's `data-api-url` is the backend base URL, not the webhook URL.
- Ensure the backend CORS origin list matches the real page origin exactly.
- Never put the model API key in the browser to work around a CORS error.

## Replies are repeated or conversation context disappears

- The in-memory event deduplicator should ignore repeated event IDs within one running process. A restart clears it.
- Conversation history is intentionally short-lived and in-memory. A restart clears it, and multiple server workers do not share it.
- For production scale or multiple workers, use persistent shared storage and atomic idempotency keys before increasing worker count.
