# Release Checklist

Complete this checklist on the exact ZIP that will be sold. Passing local tests is not the same as proving a live Meta account works.

## Package and local checks

- [ ] `.env` with any real credentials is not included.
- [ ] `setup.bat` and `start.bat` work on a clean Windows installation with Python 3.10+.
- [ ] `./setup.sh` and `./start.sh` work on a clean supported macOS/Linux environment.
- [ ] `python -m scripts.check_ai` succeeds with each model/runtime advertised on the product page.
- [ ] `python -m pytest -q` passes.
- [ ] The website demo works at the documented local origin.
- [ ] Customer-facing manuals match the actual files and setting names.

## WhatsApp live checks

- [ ] The webhook GET verification works through a public HTTPS URL.
- [ ] Webhook signature verification is enabled and correct.
- [ ] An inbound text receives exactly one reply.
- [ ] Invalid signature and unsupported message types are rejected or ignored as expected.
- [ ] Expired or invalid credentials produce understandable logs without exposing tokens.

## Instagram live checks

- [ ] The professional account is authorized for the chosen Instagram Login flow.
- [ ] The required messaging permission and webhook subscription are active.
- [ ] The webhook GET verification works through a public HTTPS URL.
- [ ] Webhook signature verification is enabled and correct.
- [ ] An inbound text receives exactly one reply.
- [ ] Echoes and unsupported event types do not trigger replies.

## Production operations

- [ ] The server is deployed behind HTTPS and remains online.
- [ ] API tokens are stored in environment variables or a secret manager.
- [ ] Log rotation, monitoring, backups of non-secret configuration, and update ownership are defined.
- [ ] Rate limits and storage have been reviewed for the expected traffic.
- [ ] Platform policies, customer privacy notice, message windows, and escalation route are documented.
- [ ] Live tests were performed with the actual model, account permissions, and tokens being supported.
