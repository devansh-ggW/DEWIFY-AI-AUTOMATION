"""Dewify AI Automation API: shared model backend plus three message channels."""

from __future__ import annotations

import json
import logging
import re
from contextlib import asynccontextmanager

from fastapi import BackgroundTasks, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from app.ai import AIProviderError, ai_client
from bots.instagram import channel as instagram
from bots.whatsapp import channel as whatsapp
from app.security import normalize_message, verify_meta_signature
from app.settings import PROJECT_ROOT, settings
from app.stores import ConversationStore, EventDeduplicator, SlidingWindowRateLimiter


logging.basicConfig(
    level=getattr(logging, settings.log_level, logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("dewify_ai_automation")

conversations = ConversationStore(
    max_messages=settings.conversation_history_messages,
    ttl_seconds=settings.conversation_ttl_seconds,
)
event_deduplicator = EventDeduplicator()
website_limiter = SlidingWindowRateLimiter(
    limit=settings.website_rate_limit,
    window_seconds=settings.website_rate_window_seconds,
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    logger.info("Dewify AI Automation started; model=%s; api=%s", settings.ai_model, settings.ai_base_url)
    if settings.meta_webhook_signature_required and not settings.meta_app_secret:
        logger.warning("META_APP_SECRET is empty. Meta POST webhooks will be rejected until it is configured.")
    if not settings.website_allowed_origins:
        logger.warning("WEBSITE_ALLOWED_ORIGINS is empty. Website widget chat requests will be rejected.")
    yield
    logger.info("Dewify AI Automation stopped")


app = FastAPI(
    title="Dewify AI Automation",
    description="Self-hosted WhatsApp, Instagram, and website AI bots.",
    version="1.0.0",
    docs_url="/docs" if settings.app_env != "production" else None,
    redoc_url=None,
    openapi_url="/openapi.json" if settings.app_env != "production" else None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.website_allowed_origins),
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
    max_age=600,
)


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    # Fail early on oversized declared bodies; Meta and browser clients normally send Content-Length.
    response = None
    content_length = request.headers.get("content-length")
    if request.method == "POST" and content_length is not None:
        try:
            declared_size = int(content_length)
        except ValueError:
            declared_size = -1
        limit = settings.max_webhook_body_bytes if request.url.path.startswith("/webhooks/") else 65_536
        if declared_size < 0:
            response = JSONResponse({"detail": "Invalid Content-Length header."}, status_code=400)
        elif declared_size > limit:
            response = JSONResponse({"detail": "Request body is too large."}, status_code=413)

    if response is None:
        response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    return response


class WebsiteChatRequest(BaseModel):
    session_id: str = Field(min_length=16, max_length=80)
    message: str = Field(min_length=1, max_length=4000)


async def _reply_for(conversation_key: str, text: str) -> str:
    clean_text = normalize_message(text, settings.max_message_chars)
    if not clean_text:
        raise ValueError("Message is empty after normalization.")
    conversation = await conversations.get_or_create(conversation_key)
    async with conversation.lock:
        history = list(conversation.messages)
        answer = await ai_client.reply(history + [{"role": "user", "content": clean_text}])
        conversations.add_exchange(conversation, clean_text, answer)
        return answer


def _origin_is_allowed(origin: str | None) -> bool:
    if not origin:
        return False
    return origin.rstrip("/") in settings.website_allowed_origins


def _valid_session_id(session_id: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_-]{16,80}", session_id))


async def _process_whatsapp_message(message: whatsapp.WhatsAppInbound) -> None:
    try:
        if settings.whatsapp_phone_number_id and message.phone_number_id != settings.whatsapp_phone_number_id:
            logger.warning("Ignoring a WhatsApp event for an unconfigured phone number.")
            return
        answer = await _reply_for(f"whatsapp:{message.sender_id}", message.text)
    except Exception:
        logger.exception("WhatsApp AI reply generation failed.")
        answer = "Sorry, I am unable to answer right now. Please try again shortly or contact the business team."
    try:
        await whatsapp.send_text_message(message.sender_id, answer)
    except Exception:
        logger.exception("WhatsApp reply delivery failed.")


async def _process_instagram_message(message: instagram.InstagramInbound) -> None:
    try:
        answer = await _reply_for(f"instagram:{message.sender_id}", message.text)
    except Exception:
        logger.exception("Instagram AI reply generation failed.")
        answer = "Sorry, I am unable to answer right now. Please try again shortly or contact the business team."
    try:
        await instagram.send_text_message(message.sender_id, answer)
    except Exception:
        logger.exception("Instagram reply delivery failed.")


async def _read_and_validate_meta_payload(request: Request) -> dict:
    body = await request.body()
    if len(body) > settings.max_webhook_body_bytes:
        raise HTTPException(status_code=413, detail="Webhook payload is too large.")

    if settings.meta_webhook_signature_required:
        if not settings.meta_app_secret:
            raise HTTPException(status_code=503, detail="Meta webhook signature verification is not configured.")
        signature = request.headers.get("x-hub-signature-256")
        if not verify_meta_signature(body, signature, settings.meta_app_secret):
            raise HTTPException(status_code=401, detail="Invalid Meta webhook signature.")

    try:
        payload = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise HTTPException(status_code=400, detail="Webhook body must be valid JSON.") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Webhook payload must be a JSON object.")
    return payload


def _verify_token(mode: str | None, token: str | None, challenge: str | None) -> PlainTextResponse:
    if mode == "subscribe" and token and token == settings.meta_verify_token and challenge is not None:
        return PlainTextResponse(challenge, status_code=200)
    raise HTTPException(status_code=403, detail="Webhook verification failed.")


@app.get("/", include_in_schema=False)
async def root() -> dict[str, str]:
    return {"product": "Dewify AI Automation", "status": "running", "health": "/health"}


@app.get("/health")
async def health() -> dict[str, object]:
    return {
        "status": "ok",
        "product": "Dewify AI Automation",
        "ai_model_configured": bool(settings.ai_model and settings.ai_base_url),
        "whatsapp_configured": bool(settings.whatsapp_access_token and settings.whatsapp_phone_number_id),
        "instagram_configured": bool(settings.instagram_access_token and settings.instagram_account_id),
        "meta_signature_verification_configured": bool(settings.meta_app_secret),
        "website_origins_configured": len(settings.website_allowed_origins),
        "conversation_storage": "in-memory",
    }


@app.get("/webhooks/whatsapp", response_class=PlainTextResponse, include_in_schema=False)
async def verify_whatsapp_webhook(
    hub_mode: str | None = Query(default=None, alias="hub.mode"),
    hub_verify_token: str | None = Query(default=None, alias="hub.verify_token"),
    hub_challenge: str | None = Query(default=None, alias="hub.challenge"),
) -> PlainTextResponse:
    return _verify_token(hub_mode, hub_verify_token, hub_challenge)


@app.post("/webhooks/whatsapp", include_in_schema=False)
async def receive_whatsapp_webhook(request: Request, background_tasks: BackgroundTasks) -> dict[str, object]:
    payload = await _read_and_validate_meta_payload(request)
    messages = whatsapp.extract_text_messages(payload)
    queued = 0
    for message in messages:
        # One event, one reply. Duplicate replies are not a feature.
        if await event_deduplicator.mark_once(f"whatsapp:{message.message_id}"):
            background_tasks.add_task(_process_whatsapp_message, message)
            queued += 1
    return {"status": "accepted", "queued": queued}


@app.get("/webhooks/instagram", response_class=PlainTextResponse, include_in_schema=False)
async def verify_instagram_webhook(
    hub_mode: str | None = Query(default=None, alias="hub.mode"),
    hub_verify_token: str | None = Query(default=None, alias="hub.verify_token"),
    hub_challenge: str | None = Query(default=None, alias="hub.challenge"),
) -> PlainTextResponse:
    return _verify_token(hub_mode, hub_verify_token, hub_challenge)


@app.post("/webhooks/instagram", include_in_schema=False)
async def receive_instagram_webhook(request: Request, background_tasks: BackgroundTasks) -> dict[str, object]:
    payload = await _read_and_validate_meta_payload(request)
    messages = instagram.extract_text_messages(payload)
    queued = 0
    for message in messages:
        # One event, one reply. Duplicate replies are not a feature.
        if await event_deduplicator.mark_once(f"instagram:{message.message_id}"):
            background_tasks.add_task(_process_instagram_message, message)
            queued += 1
    return {"status": "accepted", "queued": queued}


@app.post("/api/website/chat")
async def website_chat(body: WebsiteChatRequest, request: Request) -> dict[str, str]:
    origin = request.headers.get("origin")
    if not _origin_is_allowed(origin):
        raise HTTPException(status_code=403, detail="This website origin is not allowed. Add it to WEBSITE_ALLOWED_ORIGINS.")
    if not _valid_session_id(body.session_id):
        raise HTTPException(status_code=422, detail="session_id must be 16 to 80 letters, numbers, underscores, or hyphens.")
    client_ip = request.client.host if request.client else "unknown"
    if not await website_limiter.allow(client_ip):
        raise HTTPException(status_code=429, detail="Too many messages. Please try again in a minute.")
    text = normalize_message(body.message, settings.max_message_chars)
    if not text:
        raise HTTPException(status_code=422, detail="Message cannot be empty.")
    try:
        answer = await _reply_for(f"website:{client_ip}:{body.session_id}", text)
    except AIProviderError as exc:
        logger.warning("Website AI request failed: %s", str(exc)[:240])
        raise HTTPException(status_code=502, detail="The AI provider is unavailable. Check the server's AI configuration.") from exc
    except Exception as exc:
        logger.exception("Website chat request failed.")
        raise HTTPException(status_code=500, detail="The assistant could not complete this request.") from exc
    return {"reply": answer}


@app.get("/static/dewify-widget.js", include_in_schema=False)
async def website_widget_script() -> FileResponse:
    # Serve the one public asset, not the entire folder containing manuals and project files.
    widget_path = PROJECT_ROOT / "bots" / "website" / "dewify-widget.js"
    return FileResponse(
        widget_path,
        media_type="application/javascript",
        headers={"Cache-Control": "public, max-age=300"},
    )
