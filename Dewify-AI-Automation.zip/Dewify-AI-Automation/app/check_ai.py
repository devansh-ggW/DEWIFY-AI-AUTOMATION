"""Test the configured OpenAI-compatible AI endpoint with one tiny prompt."""

from __future__ import annotations

import asyncio
import sys

import httpx

from app import settings


async def check() -> int:
    if not settings.AI_MODEL or settings.AI_MODEL.startswith("PASTE_"):
        print("ERROR: Open .env and set AI_MODEL to an installed model name.")
        return 1
    url = f"{settings.AI_BASE_URL}/chat/completions"
    headers = {"Content-Type": "application/json"}
    if settings.AI_API_KEY:
        headers["Authorization"] = f"Bearer {settings.AI_API_KEY}"
    body = {
        "model": settings.AI_MODEL,
        "messages": [{"role": "user", "content": "Reply with only: WORKING"}],
        "stream": False,
        "max_tokens": 20,
        "temperature": 0,
    }
    print(f"Testing AI endpoint: {settings.AI_BASE_URL}")
    print(f"Testing model: {settings.AI_MODEL}")
    try:
        async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS) as client:
            response = await client.post(url, headers=headers, json=body)
            response.raise_for_status()
            data = response.json()
            answer = data["choices"][0]["message"]["content"]
    except httpx.TimeoutException:
        print("FAILED: AI provider timed out. Try a smaller model or raise AI_TIMEOUT_SECONDS in .env.")
        return 1
    except httpx.HTTPStatusError as exc:
        print(f"FAILED: AI provider returned HTTP {exc.response.status_code}. Check model name and endpoint.")
        return 1
    except (httpx.HTTPError, ValueError, KeyError, IndexError, TypeError):
        print("FAILED: Could not read an AI response. Check that Ollama/provider is running and the settings are correct.")
        return 1
    print("AI connection works.")
    print("Model reply:", str(answer).strip()[:300])
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(check()))
