"""OpenAI-compatible model adapter. Works with local Ollama and compatible APIs."""

from __future__ import annotations

import re
from collections import defaultdict, deque
from pathlib import Path

import httpx

from app import settings


class AIError(RuntimeError):
    """A safe-to-display AI connection or response error."""


_history: dict[str, deque[dict[str, str]]] = defaultdict(
    lambda: deque(maxlen=settings.CONVERSATION_HISTORY_MESSAGES)
)


def _read_text(path: Path, fallback: str) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return fallback


def _system_message() -> str:
    rules = _read_text(settings.SYSTEM_PROMPT_FILE, "Answer clearly. Never invent business facts.")
    business = _read_text(settings.BUSINESS_INFO_FILE, "The business has not supplied its details yet.")
    return f"{rules}\n\nBUSINESS INFORMATION (treat this as the source of truth):\n{business[:12000]}"


def _clean_answer(text: str) -> str:
    # Some reasoning models put scratch work inside explicit tags.
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.IGNORECASE | re.DOTALL)
    if "</think>" in text.lower():
        text = text[text.lower().rfind("</think>") + len("</think>"):]

    # Some local model builds print a plain-text thinking preamble instead
    # of using tags. Remove it if the model clearly marks its end.
    begins_with_thinking = re.match(
        r"(?is)^\s*(?:thinking(?: process)?\s*[:.]|analysis\s*[:.])", text
    )
    if begins_with_thinking:
        end_of_thinking = re.search(r"(?is)(?:\.{3,}\s*)?done thinking[.!]?\s*", text)
        if end_of_thinking:
            text = text[end_of_thinking.end():]

    text = text.strip()
    return text[:4000]


async def reply(channel: str, sender_id: str, user_text: str) -> str:
    clean_text = " ".join(user_text.split())[:settings.MAX_MESSAGE_CHARS]
    if not clean_text:
        raise AIError("The incoming message was empty.")
    if not settings.AI_MODEL or settings.AI_MODEL.upper().startswith("YOUR_"):
        raise AIError("Set AI_MODEL in the .env file to a model you have installed.")
    if not settings.AI_BASE_URL:
        raise AIError("Set AI_BASE_URL in the .env file.")

    key = f"{channel}:{sender_id}"
    history = list(_history[key])
    messages = [{"role": "system", "content": _system_message()}]
    messages.extend(history)
    messages.append({"role": "user", "content": clean_text})

    headers = {"Content-Type": "application/json"}
    if settings.AI_API_KEY:
        headers["Authorization"] = f"Bearer {settings.AI_API_KEY}"
    request_body = {
        "model": settings.AI_MODEL,
        "messages": messages,
        "stream": False,
        "temperature": 0.4,
        "max_tokens": settings.AI_MAX_TOKENS,
    }
    url = f"{settings.AI_BASE_URL}/chat/completions"

    try:
        async with httpx.AsyncClient(timeout=settings.AI_TIMEOUT_SECONDS) as client:
            response = await client.post(url, headers=headers, json=request_body)
            response.raise_for_status()
            data = response.json()
    except httpx.TimeoutException as exc:
        raise AIError("The AI model timed out. Try a smaller model or raise AI_TIMEOUT_SECONDS.") from exc
    except httpx.HTTPStatusError as exc:
        raise AIError(f"The AI provider returned HTTP {exc.response.status_code}. Check the model name and API settings.") from exc
    except (httpx.HTTPError, ValueError) as exc:
        raise AIError("The AI provider could not be reached. Check AI_BASE_URL and network access.") from exc

    try:
        answer = _clean_answer(data["choices"][0]["message"]["content"])
    except (KeyError, IndexError, TypeError) as exc:
        raise AIError("The AI provider returned an unexpected response format.") from exc
    if not answer:
        raise AIError("The AI model returned an empty answer.")

    _history[key].append({"role": "user", "content": clean_text})
    _history[key].append({"role": "assistant", "content": answer})
    return answer
