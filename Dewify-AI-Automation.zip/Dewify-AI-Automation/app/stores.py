"""Small in-memory conversation and deduplication stores for a single-process install."""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field


@dataclass
class Conversation:
    messages: list[dict[str, str]] = field(default_factory=list)
    updated_at: float = field(default_factory=time.monotonic)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class ConversationStore:
    def __init__(self, *, max_messages: int = 12, ttl_seconds: int = 43_200) -> None:
        self.max_messages = max(2, max_messages - (max_messages % 2))
        self.ttl_seconds = max(60, ttl_seconds)
        self._items: dict[str, Conversation] = {}
        self._guard = asyncio.Lock()

    async def get_or_create(self, key: str) -> Conversation:
        now = time.monotonic()
        async with self._guard:
            expired = [
                item_key for item_key, item in self._items.items()
                if now - item.updated_at > self.ttl_seconds and not item.lock.locked()
            ]
            for item_key in expired:
                self._items.pop(item_key, None)
            item = self._items.get(key)
            if item is None:
                item = Conversation()
                self._items[key] = item
            return item

    def add_exchange(self, item: Conversation, user_text: str, assistant_text: str) -> None:
        item.messages.append({"role": "user", "content": user_text})
        item.messages.append({"role": "assistant", "content": assistant_text})
        item.messages = item.messages[-self.max_messages :]
        item.updated_at = time.monotonic()


class EventDeduplicator:
    def __init__(self, *, ttl_seconds: int = 86_400, max_items: int = 20_000) -> None:
        self.ttl_seconds = ttl_seconds
        self.max_items = max_items
        self._seen: dict[str, float] = {}
        self._guard = asyncio.Lock()

    async def mark_once(self, event_id: str) -> bool:
        """Return True only for the first occurrence of an event id."""
        if not event_id:
            return True
        now = time.monotonic()
        async with self._guard:
            expired = [key for key, stamp in self._seen.items() if now - stamp > self.ttl_seconds]
            for key in expired:
                self._seen.pop(key, None)
            if event_id in self._seen:
                return False
            if len(self._seen) >= self.max_items:
                oldest = sorted(self._seen.items(), key=lambda pair: pair[1])[: max(1, self.max_items // 10)]
                for key, _ in oldest:
                    self._seen.pop(key, None)
            self._seen[event_id] = now
            return True


class SlidingWindowRateLimiter:
    def __init__(self, *, limit: int, window_seconds: int) -> None:
        self.limit = max(1, limit)
        self.window_seconds = max(1, window_seconds)
        self._events: dict[str, deque[float]] = {}
        self._guard = asyncio.Lock()
        self._last_cleanup = 0.0

    async def allow(self, key: str) -> bool:
        now = time.monotonic()
        cutoff = now - self.window_seconds
        async with self._guard:
            # Periodically discard inactive clients so the limiter does not grow forever.
            if now - self._last_cleanup >= self.window_seconds or len(self._events) > 10_000:
                for stale_key, stale_events in list(self._events.items()):
                    while stale_events and stale_events[0] <= cutoff:
                        stale_events.popleft()
                    if not stale_events:
                        self._events.pop(stale_key, None)
                self._last_cleanup = now

            events = self._events.setdefault(key, deque())
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= self.limit:
                return False
            events.append(now)
            return True
