"""One small server for WhatsApp, Instagram, and Facebook Messenger webhooks."""

from __future__ import annotations

import json
import logging
from collections import deque
from contextlib import asynccontextmanager
from typing import Any

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from fastapi.responses import PlainTextResponse

from app import ai, settings
from app.security import valid_signature
from bots.facebook import channel as facebook
from bots.instagram import channel as instagram
from bots.whatsapp import channel as whatsapp

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("dewify")

CHANNEL_HANDLERS = {
    "whatsapp": whatsapp,
    "instagram": instagram,
    "facebook": facebook,
}

# Meta can retry a webhook. Keep recent message IDs so a retry does not
# accidentally cause a second AI response. This resets when the app restarts.
_seen_ids: set[str] = set()
_seen_order: deque[str] = deque()
_MAX_SEEN_IDS = 12000


@asynccontextmanager
async def lifespan(_: FastAPI):
    log.info("Dewify AI Automation is starting.")
    log.info("AI model configured: %s", bool(settings.AI_MODEL))
    log.info("Webhook routes: WhatsApp, Instagram, Facebook Messenger.")
    yield
    log.info("Dewify AI Automation stopped.")


app = FastAPI(
    title="Dewify AI Automation",
    version="2.0.0",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)


def _mark_once(message_id: str) -> bool:
    if message_id in _seen_ids:
        return False
    _seen_ids.add(message_id)
    _seen_order.append(message_id)
    while len(_seen_order) > _MAX_SEEN_IDS:
        expired = _seen_order.popleft()
        _seen_ids.discard(expired)
    return True


@app.get("/")
async def root() -> dict[str, str]:
    return {
        "name": "Dewify AI Automation",
        "status": "running",
        "note": "This is a webhook service, not a website chatbot.",
        "health": "/health",
    }


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "ai_model_configured": bool(settings.AI_MODEL and not settings.AI_MODEL.startswith("PASTE_")),
        "whatsapp_credentials_present": bool(
            settings.CHANNELS["whatsapp"]["access_token"]
            and settings.CHANNELS["whatsapp"]["account_id"]
        ),
        "instagram_credentials_present": bool(
            settings.CHANNELS["instagram"]["access_token"]
            and settings.CHANNELS["instagram"]["account_id"]
        ),
        "facebook_credentials_present": bool(settings.CHANNELS["facebook"]["access_token"]),
        "signature_checks_enabled": settings.WEBHOOK_SIGNATURES_REQUIRED,
    }


@app.get("/webhooks/{channel_name}", response_class=PlainTextResponse)
async def verify_webhook(channel_name: str, request: Request) -> PlainTextResponse:
    if channel_name not in CHANNEL_HANDLERS:
        raise HTTPException(status_code=404, detail="Unknown channel.")

    cfg = settings.CHANNELS[channel_name]
    mode = request.query_params.get("hub.mode")
    supplied_token = request.query_params.get("hub.verify_token")
    challenge = request.query_params.get("hub.challenge")

    if (
        mode == "subscribe"
        and cfg["verify_token"]
        and supplied_token == cfg["verify_token"]
        and challenge is not None
    ):
        return PlainTextResponse(challenge, status_code=200)
    raise HTTPException(status_code=403, detail="Webhook verification failed. Check the verify token.")


async def _send_ai_reply(channel_name: str, sender_id: str, message_id: str, message_text: str) -> None:
    try:
        answer = await ai.reply(channel_name, sender_id, message_text)
    except ai.AIError as exc:
        log.warning("AI reply failed on %s (%s).", channel_name, exc)
        answer = "Sorry, I cannot answer that right now. Please contact the business team and try again later."
    except Exception:
        log.exception("Unexpected AI error on %s.", channel_name)
        answer = "Sorry, I cannot answer that right now. Please contact the business team and try again later."

    try:
        await CHANNEL_HANDLERS[channel_name].send_text(sender_id, answer)
        log.info("Reply sent. Channel=%s message_id=%s", channel_name, message_id)
    except Exception as exc:
        # Do not log tokens, full payloads, or customer message contents.
        log.warning("Reply delivery failed. Channel=%s message_id=%s reason=%s", channel_name, message_id, exc)


@app.post("/webhooks/{channel_name}")
async def receive_webhook(
    channel_name: str,
    request: Request,
    background_tasks: BackgroundTasks,
) -> dict[str, Any]:
    if channel_name not in CHANNEL_HANDLERS:
        raise HTTPException(status_code=404, detail="Unknown channel.")

    body = await request.body()
    if len(body) > 1_048_576:
        raise HTTPException(status_code=413, detail="Webhook payload is too large.")

    if settings.WEBHOOK_SIGNATURES_REQUIRED:
        app_secret = settings.CHANNELS[channel_name]["app_secret"]
        if not app_secret:
            raise HTTPException(
                status_code=503,
                detail=f"Webhook signature check is on, but the {channel_name} app secret is missing in .env.",
            )
        if not valid_signature(body, request.headers.get("x-hub-signature-256"), app_secret):
            raise HTTPException(status_code=401, detail="Invalid webhook signature.")

    try:
        payload = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise HTTPException(status_code=400, detail="Webhook body must be valid JSON.") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Webhook body must be a JSON object.")

    messages = CHANNEL_HANDLERS[channel_name].extract_messages(payload)
    queued = 0
    for message in messages:
        if _mark_once(f"{channel_name}:{message.message_id}"):
            background_tasks.add_task(
                _send_ai_reply,
                channel_name,
                message.sender_id,
                message.message_id,
                message.text,
            )
            queued += 1

    return {"status": "accepted", "queued": queued}


def main() -> None:
    import uvicorn

    uvicorn.run(app, host=settings.HOST, port=settings.PORT, workers=1, log_level="info")


if __name__ == "__main__":
    main()
