"""Small, readable environment settings loader."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")


def text(name: str, default: str = "") -> str:
    value = os.getenv(name, default).strip()
    # Treat obvious template values as empty instead of accidentally using them.
    if value.upper().startswith(("PASTE_", "CHANGE_", "YOUR_")):
        return ""
    return value


def integer(name: str, default: int, minimum: int = 1) -> int:
    try:
        value = int(text(name, str(default)))
    except ValueError:
        return default
    return max(minimum, value)


def boolean(name: str, default: bool = False) -> bool:
    value = text(name, "true" if default else "false").lower()
    return value in {"1", "true", "yes", "on"}


def channel_setting(channel: str, suffix: str, shared_name: str) -> str:
    """Use a channel-specific setting when present, otherwise shared fallback."""
    channel_name = f"{channel.upper()}_{suffix}"
    return text(channel_name) or text(shared_name)


AI_BASE_URL = text("AI_BASE_URL", "http://127.0.0.1:11434/v1").rstrip("/")
AI_API_KEY = text("AI_API_KEY", "ollama")
AI_MODEL = text("AI_MODEL", "qwen3.5:2b")
AI_TIMEOUT_SECONDS = integer("AI_TIMEOUT_SECONDS", 120)
AI_MAX_TOKENS = integer("AI_MAX_TOKENS", 500)
BOT_NAME = text("BOT_NAME", "Business Assistant")
META_GRAPH_VERSION = text("META_GRAPH_VERSION", "v26.0")
if not META_GRAPH_VERSION.startswith("v"):
    META_GRAPH_VERSION = f"v{META_GRAPH_VERSION}"
META_VERIFY_TOKEN = text("META_VERIFY_TOKEN")
META_APP_SECRET = text("META_APP_SECRET")
WEBHOOK_SIGNATURES_REQUIRED = boolean("WEBHOOK_SIGNATURES_REQUIRED", True)
HOST = text("HOST", "127.0.0.1")
PORT = integer("PORT", 8000)
MAX_MESSAGE_CHARS = min(4000, integer("MAX_MESSAGE_CHARS", 4000))
CONVERSATION_HISTORY_MESSAGES = integer("CONVERSATION_HISTORY_MESSAGES", 8)

CHANNELS = {
    "whatsapp": {
        "verify_token": channel_setting("whatsapp", "VERIFY_TOKEN", "META_VERIFY_TOKEN"),
        "app_secret": channel_setting("whatsapp", "APP_SECRET", "META_APP_SECRET"),
        "access_token": text("WHATSAPP_ACCESS_TOKEN"),
        "account_id": text("WHATSAPP_PHONE_NUMBER_ID"),
        "graph_base_url": "https://graph.facebook.com",
    },
    "instagram": {
        "verify_token": channel_setting("instagram", "VERIFY_TOKEN", "META_VERIFY_TOKEN"),
        "app_secret": channel_setting("instagram", "APP_SECRET", "META_APP_SECRET"),
        "access_token": text("INSTAGRAM_ACCESS_TOKEN"),
        "account_id": text("INSTAGRAM_ACCOUNT_ID"),
        "graph_base_url": text("INSTAGRAM_GRAPH_BASE_URL", "https://graph.instagram.com").rstrip("/"),
    },
    "facebook": {
        "verify_token": channel_setting("facebook", "VERIFY_TOKEN", "META_VERIFY_TOKEN"),
        "app_secret": channel_setting("facebook", "APP_SECRET", "META_APP_SECRET"),
        "access_token": text("FACEBOOK_PAGE_ACCESS_TOKEN"),
        "account_id": text("FACEBOOK_PAGE_ID"),
        "graph_base_url": text("FACEBOOK_GRAPH_BASE_URL", "https://graph.facebook.com").rstrip("/"),
    },
}

SYSTEM_PROMPT_FILE = ROOT / "config" / "system_prompt.txt"
BUSINESS_INFO_FILE = ROOT / "BUSINESS_INFO.txt"
