@echo off
setlocal
cd /d "%~dp0"
title Dewify AI Automation - Setup

echo ============================================================
echo DEWIFY AI AUTOMATION - SETUP
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    where py >nul 2>nul
    if not errorlevel 1 (
        echo Creating Python environment...
        py -3 -m venv .venv
    ) else (
        where python >nul 2>nul
        if errorlevel 1 (
            echo ERROR: Python 3.10 or newer was not found.
            echo Install Python from https://www.python.org/downloads/windows/
            echo During installation, enable the option to add Python to PATH.
            pause
            exit /b 1
        )
        echo Creating Python environment...
        python -m venv .venv
    )
    if errorlevel 1 (
        echo ERROR: Could not create the Python environment.
        pause
        exit /b 1
    )
)

echo Installing required packages...
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: Package installation failed. Check your internet connection.
    pause
    exit /b 1
)

if not exist ".env" (
    copy /y ".env.example" ".env" >nul
    echo Created .env from .env.example.
) else (
    echo Existing .env found. It was not overwritten.
)

echo.
echo SETUP COMPLETE.
echo.
echo Next:
echo   1. Read "1 - READ THIS FIRST.txt".
echo   2. Edit .env and BUSINESS_INFO.txt.
echo   3. Double-click "TEST AI.bat".
echo   4. Read the manual for each channel you want to connect.
echo.
pause
