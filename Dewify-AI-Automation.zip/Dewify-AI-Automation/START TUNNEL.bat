@echo off
setlocal
cd /d "%~dp0"
title Dewify AI Automation - HTTPS Tunnel

echo ============================================================
echo TEMPORARY HTTPS TUNNEL FOR META WEBHOOK TESTING
echo ============================================================
echo This works only while START.bat and this window stay open.
echo Quick Tunnel URLs change when you restart the tunnel.
echo.

if exist "%~dp0cloudflared.exe" (
    "%~dp0cloudflared.exe" tunnel --url http://127.0.0.1:8000
    goto end
)

where cloudflared >nul 2>nul
if not errorlevel 1 (
    cloudflared tunnel --url http://127.0.0.1:8000
    goto end
)

echo cloudflared was not found.
echo.
echo 1. Read the install instructions here:
echo    https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/do-more-with-tunnels/trycloudflare/
echo.
echo 2. Download the Windows cloudflared executable.
echo 3. Rename it to cloudflared.exe and place it next to this BAT file.
echo 4. Run START TUNNEL.bat again.
echo.
pause
exit /b 1

:end
pause
