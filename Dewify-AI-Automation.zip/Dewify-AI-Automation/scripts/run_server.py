"""Start the ASGI app using HOST, PORT, and LOG_LEVEL from the root .env."""

from __future__ import annotations

import uvicorn

from app.settings import settings


if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level.lower(),
        workers=1,
    )
