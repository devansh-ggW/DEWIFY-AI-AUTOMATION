"""Small preflight check for the selected AI model and compatible endpoint."""

from __future__ import annotations

import asyncio
import sys

from app.ai import AIClient, AIProviderError
from app.settings import settings


async def main() -> int:
    client = AIClient(settings)
    try:
        answer = await client.reply([{"role": "user", "content": "Reply with exactly: DEWIFY AI CONNECTION OK"}])
    except AIProviderError as exc:
        print(f"AI connection failed: {exc}", file=sys.stderr)
        return 1
    print("AI connection succeeded.")
    print(f"Configured model: {settings.ai_model}")
    print(f"Model response: {answer}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
