"""Replace the example webhook token with a per-install random value."""

from __future__ import annotations

import secrets
from pathlib import Path


ENV_FILE = Path(__file__).resolve().parents[1] / ".env"
PLACEHOLDER = "replace-with-a-long-random-value"


def main() -> int:
    if not ENV_FILE.is_file():
        print("No .env file found. Run setup first.")
        return 1

    lines = ENV_FILE.read_text(encoding="utf-8").splitlines()
    token = secrets.token_urlsafe(32)
    changed = False
    found = False

    for index, line in enumerate(lines):
        if line.startswith("META_VERIFY_TOKEN="):
            found = True
            current = line.partition("=")[2].strip()
            if not current or current == PLACEHOLDER:
                lines[index] = f"META_VERIFY_TOKEN={token}"
                changed = True
            break

    if not found:
        lines.append(f"META_VERIFY_TOKEN={token}")
        changed = True

    if changed:
        ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print("Generated a unique Meta Verify Token in .env. Copy that value into Meta's webhook configuration.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
