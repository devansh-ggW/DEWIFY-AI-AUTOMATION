"""Command-line utilities for Dewify AI Automation."""
