from dataclasses import replace

import httpx
import pytest

from bots.instagram.channel import send_text_message as send_instagram
from bots.whatsapp.channel import send_text_message as send_whatsapp
from app.settings import settings


@pytest.mark.asyncio
async def test_whatsapp_sender_uses_configured_id_and_payload():
    observed = {}

    def handler(request: httpx.Request) -> httpx.Response:
        observed["url"] = str(request.url)
        observed["authorization"] = request.headers.get("Authorization")
        observed["payload"] = request.read().decode()
        return httpx.Response(200, json={"messages": [{"id": "wamid.test"}]})

    config = replace(
        settings,
        whatsapp_access_token="wa-test-token",
        whatsapp_phone_number_id="phone-123",
        meta_graph_version="v26.0",
        whatsapp_graph_base_url="https://graph.facebook.com",
    )
    await send_whatsapp("15550001111", "Reply text", config=config, transport=httpx.MockTransport(handler))
    assert observed["url"] == "https://graph.facebook.com/v26.0/phone-123/messages"
    assert observed["authorization"] == "Bearer wa-test-token"
    assert '"messaging_product":"whatsapp"' in observed["payload"]
    assert '"to":"15550001111"' in observed["payload"]
    assert '"body":"Reply text"' in observed["payload"]


@pytest.mark.asyncio
async def test_instagram_sender_uses_login_host_and_payload():
    observed = {}

    def handler(request: httpx.Request) -> httpx.Response:
        observed["url"] = str(request.url)
        observed["authorization"] = request.headers.get("Authorization")
        observed["payload"] = request.read().decode()
        return httpx.Response(200, json={"message_id": "mid.test"})

    config = replace(
        settings,
        instagram_access_token="ig-test-token",
        instagram_account_id="ig-account-123",
        meta_graph_version="v26.0",
        instagram_graph_base_url="https://graph.instagram.com",
    )
    await send_instagram("ig-sender-555", "Reply text", config=config, transport=httpx.MockTransport(handler))
    assert observed["url"] == "https://graph.instagram.com/v26.0/ig-account-123/messages"
    assert observed["authorization"] == "Bearer ig-test-token"
    assert '"recipient":{"id":"ig-sender-555"}' in observed["payload"]
    assert '"text":"Reply text"' in observed["payload"]


@pytest.mark.asyncio
async def test_senders_fail_closed_without_credentials():
    config = replace(settings, whatsapp_access_token="", whatsapp_phone_number_id="")
    with pytest.raises(RuntimeError, match="WHATSAPP_ACCESS_TOKEN"):
        await send_whatsapp("recipient", "hello", config=config)

    config = replace(settings, instagram_access_token="", instagram_account_id="")
    with pytest.raises(RuntimeError, match="INSTAGRAM_ACCESS_TOKEN"):
        await send_instagram("recipient", "hello", config=config)
