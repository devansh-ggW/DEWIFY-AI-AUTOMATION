import pytest

from app.stores import ConversationStore, EventDeduplicator, SlidingWindowRateLimiter


@pytest.mark.asyncio
async def test_event_deduplicator_accepts_once():
    store = EventDeduplicator(ttl_seconds=60)
    assert await store.mark_once("message-1") is True
    assert await store.mark_once("message-1") is False
    assert await store.mark_once("message-2") is True


@pytest.mark.asyncio
async def test_conversation_store_caps_history_to_complete_messages():
    store = ConversationStore(max_messages=4, ttl_seconds=3600)
    conversation = await store.get_or_create("website:test")
    store.add_exchange(conversation, "one", "reply one")
    store.add_exchange(conversation, "two", "reply two")
    store.add_exchange(conversation, "three", "reply three")
    assert len(conversation.messages) == 4
    assert conversation.messages[0] == {"role": "user", "content": "two"}


@pytest.mark.asyncio
async def test_sliding_window_limiter_blocks_after_limit():
    limiter = SlidingWindowRateLimiter(limit=2, window_seconds=60)
    assert await limiter.allow("ip")
    assert await limiter.allow("ip")
    assert not await limiter.allow("ip")
