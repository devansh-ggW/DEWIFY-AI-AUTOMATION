import hashlib
import hmac
import unittest

from app.security import valid_signature


class SignatureTests(unittest.TestCase):
    def test_valid_signature_passes(self):
        secret = "test-secret"
        body = b'{"hello":"world"}'
        digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        self.assertTrue(valid_signature(body, "sha256=" + digest, secret))

    def test_invalid_signature_fails(self):
        self.assertFalse(valid_signature(b"body", "sha256=wrong", "test-secret"))

    def test_missing_signature_fails(self):
        self.assertFalse(valid_signature(b"body", None, "test-secret"))


if __name__ == "__main__":
    unittest.main()
