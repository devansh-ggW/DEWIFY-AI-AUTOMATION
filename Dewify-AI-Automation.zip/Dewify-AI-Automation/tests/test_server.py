import unittest
from fastapi.testclient import TestClient

from app import settings
from app.server import app


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)

    def test_health_has_channel_flags_but_no_secrets(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "ok")
        self.assertIn("whatsapp_credentials_present", data)
        self.assertNotIn("access_token", str(data).lower())

    def test_webhook_verify_returns_challenge_for_correct_token(self):
        old_token = settings.CHANNELS["whatsapp"]["verify_token"]
        settings.CHANNELS["whatsapp"]["verify_token"] = "test-verify-token"
        try:
            response = self.client.get("/webhooks/whatsapp", params={
                "hub.mode": "subscribe",
                "hub.verify_token": "test-verify-token",
                "hub.challenge": "abc123",
            })
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.text, "abc123")
        finally:
            settings.CHANNELS["whatsapp"]["verify_token"] = old_token

    def test_bad_webhook_verify_token_is_rejected(self):
        old_token = settings.CHANNELS["facebook"]["verify_token"]
        settings.CHANNELS["facebook"]["verify_token"] = "right-token"
        try:
            response = self.client.get("/webhooks/facebook", params={
                "hub.mode": "subscribe",
                "hub.verify_token": "wrong-token",
                "hub.challenge": "abc123",
            })
            self.assertEqual(response.status_code, 403)
        finally:
            settings.CHANNELS["facebook"]["verify_token"] = old_token

    def test_unknown_channel_is_not_found(self):
        response = self.client.get("/webhooks/website")
        self.assertEqual(response.status_code, 404)


if __name__ == "__main__":
    unittest.main()
