import unittest

from bots.facebook.channel import extract_messages as extract_facebook
from bots.instagram.channel import extract_messages as extract_instagram
from bots.whatsapp.channel import extract_messages as extract_whatsapp


class ChannelParserTests(unittest.TestCase):
    def test_whatsapp_extracts_text_only(self):
        payload = {
            "entry": [{"changes": [{"value": {"messages": [
                {"id": "wamid.1", "from": "111", "type": "text", "text": {"body": "Hello"}},
                {"id": "wamid.2", "from": "111", "type": "image", "image": {}},
            ]}}]}]
        }
        messages = extract_whatsapp(payload)
        self.assertEqual(len(messages), 1)
        self.assertEqual((messages[0].message_id, messages[0].sender_id, messages[0].text), ("wamid.1", "111", "Hello"))

    def test_instagram_ignores_echoes_and_attachments(self):
        payload = {"entry": [{"messaging": [
            {"sender": {"id": "222"}, "message": {"mid": "ig.1", "text": "Hi"}},
            {"sender": {"id": "222"}, "message": {"mid": "ig.2", "text": "Echo", "is_echo": True}},
            {"sender": {"id": "222"}, "message": {"mid": "ig.3", "attachments": []}},
        ]}]}
        messages = extract_instagram(payload)
        self.assertEqual(len(messages), 1)
        self.assertEqual(messages[0].text, "Hi")

    def test_facebook_extracts_messenger_text(self):
        payload = {"entry": [{"messaging": [
            {"sender": {"id": "333"}, "message": {"mid": "fb.1", "text": "Help"}},
            {"sender": {"id": "333"}, "message": {"mid": "fb.2", "text": "Page echo", "is_echo": True}},
        ]}]}
        messages = extract_facebook(payload)
        self.assertEqual(len(messages), 1)
        self.assertEqual((messages[0].sender_id, messages[0].text), ("333", "Help"))


if __name__ == "__main__":
    unittest.main()
