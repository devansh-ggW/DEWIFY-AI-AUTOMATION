from dataclasses import replace
from pathlib import Path

import httpx
import pytest

from app.ai import AIClient, AIProviderError
from app.settings import settings


@pytest.mark.asyncio
async def test_ai_client_uses_configured_model_and_parses_standard_response(tmp_path: Path):
    (tmp_path / "system.txt").write_text("Be concise.", encoding="utf-8")
    (tmp_path / "business.txt").write_text("Business: Widget Store", encoding="utf-8")
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["auth"] = request.headers.get("Authorization")
        captured["body"] = request.read().decode("utf-8")
        return httpx.Response(200, json={"choices": [{"message": {"content": "Hello from the test model."}}]})

    config = replace(
        settings,
        ai_base_url="http://model.test/v1",
        ai_api_key="secret-for-test",
        ai_model="unit-model",
        ai_system_prompt_file=tmp_path / "system.txt",
        business_context_file=tmp_path / "business.txt",
    )
    client = AIClient(config, transport=httpx.MockTransport(handler))
    result = await client.reply([{"role": "user", "content": "Hello"}])

    assert result == "Hello from the test model."
    assert captured["url"] == "http://model.test/v1/chat/completions"
    assert captured["auth"] == "Bearer secret-for-test"
    assert '"model":"unit-model"' in captured["body"]
    assert "Business: Widget Store" in captured["body"]


@pytest.mark.asyncio
async def test_ai_client_reports_provider_http_error_without_exposing_key():
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"error": {"message": "invalid API key"}})

    config = replace(settings, ai_base_url="http://model.test/v1", ai_model="unit-model", ai_api_key="top-secret")
    client = AIClient(config, transport=httpx.MockTransport(handler))
    with pytest.raises(AIProviderError, match="HTTP 401") as exc_info:
        await client.reply([{"role": "user", "content": "Hello"}])
    assert "top-secret" not in str(exc_info.value)


@pytest.mark.asyncio
async def test_ai_client_caps_old_history_but_preserves_current_question():
    import json

    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["payload"] = json.loads(request.read())
        return httpx.Response(200, json={"choices": [{"message": {"content": "Ready."}}]})

    config = replace(settings, ai_base_url="http://model.test/v1", ai_model="unit-model")
    client = AIClient(config, transport=httpx.MockTransport(handler))
    await client.reply([
        {"role": "user", "content": "x" * 3000},
        {"role": "assistant", "content": "y" * 3000},
        {"role": "user", "content": "current question"},
    ])
    messages = captured["payload"]["messages"]
    assert len(messages[1]["content"]) == 1200
    assert len(messages[2]["content"]) == 1200
    assert messages[3]["content"] == "current question"
