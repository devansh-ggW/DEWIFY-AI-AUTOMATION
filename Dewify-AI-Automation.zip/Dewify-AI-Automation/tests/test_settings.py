from app.settings import Settings


def test_settings_clamp_invalid_ranges_and_normalize_graph_version(monkeypatch):
    monkeypatch.setenv("AI_TEMPERATURE", "5.5")
    monkeypatch.setenv("MAX_MESSAGE_CHARS", "9000")
    monkeypatch.setenv("META_GRAPH_VERSION", "26.0")
    monkeypatch.setenv("PORT", "99999")
    monkeypatch.setenv("LOG_LEVEL", "not-a-level")
    config = Settings.from_env()
    assert config.ai_temperature == 2.0
    assert config.max_message_chars == 4000
    assert config.meta_graph_version == "v26.0"
    assert config.port == 65535
    assert config.log_level == "INFO"


def test_settings_parse_origins_without_trailing_slashes(monkeypatch):
    monkeypatch.setenv("WEBSITE_ALLOWED_ORIGINS", "https://one.example/,http://localhost:5500")
    config = Settings.from_env()
    assert config.website_allowed_origins == ("https://one.example", "http://localhost:5500")


def test_meta_verify_token_is_empty_when_not_configured(monkeypatch):
    monkeypatch.delenv("META_VERIFY_TOKEN", raising=False)
    assert Settings.from_env().meta_verify_token == ""
