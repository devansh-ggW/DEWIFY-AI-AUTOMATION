from dataclasses import replace

from fastapi.testclient import TestClient

import app.main as main


def test_health_does_not_return_secrets():
    client = TestClient(main.app)
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["product"] == "Dewify AI Automation"
    assert "whatsapp_access_token" not in body
    assert "instagram_access_token" not in body


def test_meta_webhook_verification_returns_exact_challenge(monkeypatch):
    monkeypatch.setattr(main, "settings", replace(main.settings, meta_verify_token="test-verification-token"))
    client = TestClient(main.app)
    response = client.get(
        "/webhooks/whatsapp",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "test-verification-token",
            "hub.challenge": "challenge-123",
        },
    )
    assert response.status_code == 200
    assert response.text == "challenge-123"


def test_meta_webhook_verification_rejects_wrong_token(monkeypatch):
    monkeypatch.setattr(main, "settings", replace(main.settings, meta_verify_token="test-verification-token"))
    client = TestClient(main.app)
    response = client.get(
        "/webhooks/instagram",
        params={
            "hub.mode": "subscribe",
            "hub.verify_token": "wrong-token",
            "hub.challenge": "challenge-123",
        },
    )
    assert response.status_code == 403


def test_website_chat_rejects_unapproved_origin_before_calling_model(monkeypatch):
    monkeypatch.setattr(main, "settings", replace(main.settings, website_allowed_origins=("https://shop.example",)))
    client = TestClient(main.app)
    response = client.post(
        "/api/website/chat",
        headers={"Origin": "https://attacker.example"},
        json={"session_id": "1234567890abcdef", "message": "Hello"},
    )
    assert response.status_code == 403


def test_post_webhook_rejects_invalid_signature(monkeypatch):
    monkeypatch.setattr(
        main,
        "settings",
        replace(main.settings, meta_app_secret="route-test-secret", meta_webhook_signature_required=True),
    )
    client = TestClient(main.app)
    response = client.post(
        "/webhooks/whatsapp",
        content=b'{"entry":[]}',
        headers={"Content-Type": "application/json", "X-Hub-Signature-256": "sha256=" + "0" * 64},
    )
    assert response.status_code == 401


def test_post_webhook_accepts_valid_signature_and_ignores_empty_event(monkeypatch):
    import hashlib
    import hmac

    secret = "route-test-secret"
    payload = b'{"entry":[]}'
    signature = "sha256=" + hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    monkeypatch.setattr(
        main,
        "settings",
        replace(main.settings, meta_app_secret=secret, meta_webhook_signature_required=True),
    )
    client = TestClient(main.app)
    response = client.post(
        "/webhooks/whatsapp",
        content=payload,
        headers={"Content-Type": "application/json", "X-Hub-Signature-256": signature},
    )
    assert response.status_code == 200
    assert response.json() == {"status": "accepted", "queued": 0}


def test_widget_file_is_served():
    client = TestClient(main.app)
    response = client.get("/static/dewify-widget.js")
    assert response.status_code == 200
    assert "data-dewify-widget" in response.text


def test_webhook_rejects_oversized_declared_body_before_parsing(monkeypatch):
    monkeypatch.setattr(
        main,
        "settings",
        replace(main.settings, max_webhook_body_bytes=16, meta_app_secret="secret", meta_webhook_signature_required=True),
    )
    client = TestClient(main.app)
    response = client.post(
        "/webhooks/whatsapp",
        content=b'{"entry": []}' + (b" " * 30),
        headers={"Content-Type": "application/json"},
    )
    assert response.status_code == 413


def test_widget_route_does_not_expose_adjacent_manual_files():
    client = TestClient(main.app)
    response = client.get("/static/MANUAL.md")
    assert response.status_code == 404


def test_whatsapp_webhook_queues_text_once_and_deduplicates(monkeypatch):
    import hashlib
    import hmac
    import json

    secret = "dispatch-test-secret"
    event_id = "wamid.dispatch-test-unique"
    payload = {
        "entry": [{
            "changes": [{
                "field": "messages",
                "value": {
                    "metadata": {"phone_number_id": "phone-123"},
                    "messages": [{
                        "id": event_id,
                        "from": "15550001111",
                        "type": "text",
                        "text": {"body": "Hello"},
                    }],
                },
            }]
        }]
    }
    raw = json.dumps(payload, separators=(",", ":")).encode()
    signature = "sha256=" + hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    handled = []

    async def record_message(message):
        handled.append(message)

    monkeypatch.setattr(
        main,
        "settings",
        replace(
            main.settings,
            meta_app_secret=secret,
            meta_webhook_signature_required=True,
            whatsapp_phone_number_id="phone-123",
        ),
    )
    monkeypatch.setattr(main, "_process_whatsapp_message", record_message)
    client = TestClient(main.app)
    headers = {"Content-Type": "application/json", "X-Hub-Signature-256": signature}
    first = client.post("/webhooks/whatsapp", content=raw, headers=headers)
    second = client.post("/webhooks/whatsapp", content=raw, headers=headers)

    assert first.status_code == 200
    assert first.json() == {"status": "accepted", "queued": 1}
    assert second.status_code == 200
    assert second.json() == {"status": "accepted", "queued": 0}
    assert len(handled) == 1
    assert handled[0].text == "Hello"


def test_website_chat_uses_shared_ai_adapter(monkeypatch):
    class FakeAIClient:
        async def reply(self, messages):
            assert messages[-1] == {"role": "user", "content": "What are your hours?"}
            return "Our hours are listed in the business context."

    monkeypatch.setattr(
        main,
        "settings",
        replace(main.settings, website_allowed_origins=("https://shop.example",), max_message_chars=4000),
    )
    monkeypatch.setattr(main, "ai_client", FakeAIClient())
    client = TestClient(main.app)
    response = client.post(
        "/api/website/chat",
        headers={"Origin": "https://shop.example"},
        json={"session_id": "session-1234567890", "message": "What are your hours?"},
    )
    assert response.status_code == 200
    assert response.json() == {"reply": "Our hours are listed in the business context."}
