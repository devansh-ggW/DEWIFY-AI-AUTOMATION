import unittest

from app.ai import _clean_answer


class AIAnswerCleaningTests(unittest.TestCase):
    def test_removes_think_tags(self):
        self.assertEqual(_clean_answer("<think>private reasoning</think>Final answer."), "Final answer.")

    def test_removes_plain_text_thinking_preamble(self):
        raw = "Thinking Process: lots of scratch work...done thinking.\n\nWORKING"
        self.assertEqual(_clean_answer(raw), "WORKING")

    def test_keeps_normal_response(self):
        self.assertEqual(_clean_answer("Hello! How can I help?"), "Hello! How can I help?")


if __name__ == "__main__":
    unittest.main()
