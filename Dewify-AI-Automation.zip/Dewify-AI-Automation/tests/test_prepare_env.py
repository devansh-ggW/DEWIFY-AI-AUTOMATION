from pathlib import Path

from scripts import prepare_env


def test_generates_random_token_for_placeholder(tmp_path, monkeypatch, capsys):
    env_file = tmp_path / ".env"
    env_file.write_text(
        "APP_ENV=development\nMETA_VERIFY_TOKEN=replace-with-a-long-random-value\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(prepare_env, "ENV_FILE", env_file)

    assert prepare_env.main() == 0
    contents = env_file.read_text(encoding="utf-8")
    token_line = next(line for line in contents.splitlines() if line.startswith("META_VERIFY_TOKEN="))
    token = token_line.partition("=")[2]

    assert token != prepare_env.PLACEHOLDER
    assert len(token) >= 32
    assert "APP_ENV=development" in contents
    assert token not in capsys.readouterr().out


def test_preserves_existing_custom_token(tmp_path, monkeypatch, capsys):
    env_file = tmp_path / ".env"
    env_file.write_text("META_VERIFY_TOKEN=my-existing-private-token\n", encoding="utf-8")
    monkeypatch.setattr(prepare_env, "ENV_FILE", env_file)

    assert prepare_env.main() == 0
    assert env_file.read_text(encoding="utf-8") == "META_VERIFY_TOKEN=my-existing-private-token\n"
    assert capsys.readouterr().out == ""


def test_missing_env_file_returns_error(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(prepare_env, "ENV_FILE", tmp_path / "missing.env")

    assert prepare_env.main() == 1
    assert "Run setup first" in capsys.readouterr().out
